package com.df.a1_2_diegofabrega;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class SuccessActivity extends AppCompatActivity {

    Bundle datos;
    TextView titulo;
    TextView mensaje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);
        recepcion();
    }

    private void recepcion(){
        datos = getIntent().getExtras();
        titulo =(TextView) findViewById(R.id.tituloE);
        mensaje =(TextView) findViewById(R.id.mensajeE);
        titulo.setText(datos.getString("titulo"));
        mensaje.setText(datos.getString("mensaje"));
    }

    public void Regresar(View v){
        Intent c = new Intent(this,MainActivity.class);
        startActivity(c);
    }
}