package com.df.a1_2_diegofabrega;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText correo;
    private EditText pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        correo = (EditText) findViewById(R.id.correo);
        pass = (EditText) findViewById(R.id.pass);
    }

    public void cambio(View v){ // de acuerdo al resultado cambia y da mensaje a un activity u otro,
        Intent c;
        String titulo;
        String mensaje;

        if (analisis()){
            titulo=" ¡Exito!";
            mensaje="Ha ingresado correctamente las credenciales.";
            c= new Intent(this,SuccessActivity.class);
        }else{
            titulo=" ¡Error!";
            mensaje=" Las credenciales ingresadas no son validas.";
            c = new Intent(this,FailActivity.class);
        }
        c.putExtra("titulo",titulo);
        c.putExtra("mensaje",mensaje);
        startActivity(c);
    }

    private boolean analisis(){   // Analiza credenciales ingresadas y devuelve resultado
        String co = correo.getText().toString().toLowerCase().trim();
        String pa = pass.getText().toString().toLowerCase().trim();
        if (co.equals("correo@correo.cl") && pa.equals("contraseña")){
            return true;
        }
        else{
            return false;
        }
    }

}